﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Initial_UI_Mariano_Optical
{
    static class Connection
    {
        public static string empID;
        public static string patientID;

        
    }
}
