create table employee(
	empid		int,
	firstname	varchar(10),
	midname		varchar(10),
	lastname	varchar(10),
	emppass		varchar(15),
);